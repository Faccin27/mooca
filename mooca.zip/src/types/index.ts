import type React from "react"

export interface HeroSlide {
  image: string
  title: string
  subtitle: string
  description: string
  features: string[]
}
